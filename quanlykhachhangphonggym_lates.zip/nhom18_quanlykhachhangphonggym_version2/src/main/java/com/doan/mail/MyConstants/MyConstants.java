package com.doan.mail.MyConstants;

public class MyConstants {
	// Replace with your email here:  
    public static final String MY_EMAIL = "ndt.gym@gmail.com";
 
    // Replace password!!
    public static final String  MY_PASSWORD = "aevjjkmckdqlgudq";
 
    // And receiver!
    public static final String FRIEND_EMAIL = "thanhnamvo2000@gmail.com";
}
